SYNTHETIC SAMPLE - NOT REAL HEALTH DATA

This folder imitates the layout of a Samsung Health "Download personal data" export (Galaxy Watch).
Every value was invented by tools/samsung-sample/generate.ts in the AURA project, using a seeded random generator.
AURA labels anything imported from it as SYNTHETIC.
